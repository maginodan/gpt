import os
from statistics import mean, mode, multimode  # Standard Python library

your_reg_number = '22/U/21768/PS'  # Update your registration number
your_name = 'Magino Daniel'  # Update your name

def print_menu():
    print("--------------------Menu--------------------")
    print("1 - Add student with marks")
    print("2 - Delete student, given an admin_no")
    print("3 - View statistics about the grades")
    print("4 - View student grades")
    print("5 - Edit student grades")
    print("6 - Print Gradebook")
    print("m - Print menu")
    print("c - Clear Screen")
    print("q - Quit system\n")

print()
print(f"Welcome to students Gradebook\nBy".upper())
print(f"{your_name} - {your_reg_number}\n")

# Print menu for the first time
print_menu()

# Initialize the gradebook using dict()
grade_book = dict()

# Function to calculate statistics
def calculate_statistics(subject_marks):
    if not subject_marks:
        return None, None, None, None
    avg = mean(subject_marks)
    lowest = min(subject_marks)
    highest = max(subject_marks)
    try:
        most_frequent = mode(subject_marks)
        frequency = subject_marks.count(most_frequent)
    except:
        most_frequent = multimode(subject_marks)
        frequency = max(subject_marks.count(mf) for mf in most_frequent)
    return avg, most_frequent, frequency, lowest, highest

while True:
    choice = input("\n--------------------\nEnter your choice\n")
    
    if choice == '1':
        # Add student
        admin_no = input("Enter Admin No: ")
        name = input("Enter Student Name: ")
        try:
            # Optionally, allow the teacher/user to input marks
            maths = int(input("Enter Maths marks (0-100): "))
            sst = int(input("Enter SST marks (0-100): "))
            science = int(input("Enter Science marks (0-100): "))
            eng = int(input("Enter English marks (0-100): "))
            # Ensure valid marks range
            if all(0 <= mark <= 100 for mark in [maths, sst, science, eng]):
                grade_book[admin_no] = {'name': name, 'maths': maths, 'sst': sst, 'science': science, 'eng': eng}
                print(f"Student {name} added successfully!")
                print(f"Total number of students: {len(grade_book)}")
            else:
                print("Error: Marks should be between 0 and 100.")
        except ValueError:
            print("Error: Invalid input, please enter valid numbers for marks.")
    
    elif choice == '2':
        # Delete student
        admin_no = input("Enter Admin No to delete: ")
        if admin_no in grade_book:
            del grade_book[admin_no]
            print("Student deleted successfully.")
        else:
            print("Student not found.")
    
    elif choice == '3':
        # View statistics
        if not grade_book:
            print("Gradebook is empty. No statistics available.")
        else:
            # Collect marks for each subject
            maths_marks = [student['maths'] for student in grade_book.values()]
            sst_marks = [student['sst'] for student in grade_book.values()]
            science_marks = [student['science'] for student in grade_book.values()]
            eng_marks = [student['eng'] for student in grade_book.values()]

            # Calculate statistics for Maths
            avg, mode_value, mode_freq, lowest, highest = calculate_statistics(maths_marks)
            if avg is not None:
                print(f"Maths - Mean: {avg:.2f}, Mode: {mode_value}, Mode Frequency: {mode_freq}, Lowest: {lowest}, Highest: {highest}")
            
            # Calculate statistics for SST
            avg, mode_value, mode_freq, lowest, highest = calculate_statistics(sst_marks)
            if avg is not None:
                print(f"SST - Mean: {avg:.2f}, Mode: {mode_value}, Mode Frequency: {mode_freq}, Lowest: {lowest}, Highest: {highest}")
            
            # Calculate statistics for Science
            avg, mode_value, mode_freq, lowest, highest = calculate_statistics(science_marks)
            if avg is not None:
                print(f"Science - Mean: {avg:.2f}, Mode: {mode_value}, Mode Frequency: {mode_freq}, Lowest: {lowest}, Highest: {highest}")
            
            # Calculate statistics for English
            avg, mode_value, mode_freq, lowest, highest = calculate_statistics(eng_marks)
            if avg is not None:
                print(f"English - Mean: {avg:.2f}, Mode: {mode_value}, Mode Frequency: {mode_freq}, Lowest: {lowest}, Highest: {highest}")

    elif choice == '4':
        # View student grades
        admin_no = input("Enter Admin No: ")
        student = grade_book.get(admin_no)
        if student:
            print(f"Grades for {student['name']} (Admin No: {admin_no}):")
            print(f"Maths: {student['maths']}, SST: {student['sst']}, Science: {student['science']}, English: {student['eng']}")
        else:
            print("Student not found.")
    
    elif choice == '5':
        # Edit student grades
        admin_no = input("Enter Admin No: ")
        student = grade_book.get(admin_no)
        if student:
            print(f"Editing grades for {student['name']} (Admin No: {admin_no})")
            try:
                student['maths'] = int(input("Enter new Maths marks: "))
                student['sst'] = int(input("Enter new SST marks: "))
                student['science'] = int(input("Enter new Science marks: "))
                student['eng'] = int(input("Enter new English marks: "))
                print("Grades updated successfully!")
            except ValueError:
                print("Error: Invalid input, please enter valid numbers for marks.")
        else:
            print("Student not found.")
    
    elif choice == '6':
        # Print gradebook
        if not grade_book:
            print("Gradebook is empty.")
        else:
            print(f"{'Admin No':<10} {'Name':<15} {'Maths':<10} {'SST':<10} {'Science':<10} {'English':<10}")
            for admin_no, student in grade_book.items():
                print(f"{admin_no:<10} {student['name']:<15} {student['maths']:<10} {student['sst']:<10} {student['science']:<10} {student['eng']:<10}")
    
    elif choice == 'm':
        print_menu()
    
    elif choice == 'c':
        os.system('cls' if os.name == 'nt' else 'clear')  # Clear screen
    
    elif choice == 'q':
        print('Bye bye')
        break
    
    else:
        print("Invalid choice, please try again.")
