class Student:
    id_counter = 0
    University="Makerere"

    def __init__(self, Reg_number,Student_number,Fullname):
        self.Reg_number = Reg_number
        self.Student_number = Student_number
        self.Fullname= Fullname
        Student.id_counter +=1
        self.id_number = Student.id_counter

    def print_statement(self,college=None,department=None):
        print(f"Fullname: {self.Fullname}")
        print(f"University: {Student.University}")
        print(f"college:{college}")
        print(f"Reg_number: {self.Reg_number}")
        print(f"Student_number: {self.Student_number}")
        if department:
           print(f"Depatment: {department}")
        print(f"id_number: {self.id_number}")
        print(f"Total_student: {Student.id_counter}\n")    


class CEDAT_Student(Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)    

    def print_statement(self, college=None):
        super().print_statement(college = "CEDAT")  


class COCIS_Student(Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)
    def print_statement(self, college=None, department=None):
        super().print_statement(college = "COCIS",department=department) 


class EDUC_Student(Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)
    def print_statement(self, college=None):
        super().print_statement(college = "EDUCATION")         

class EASLIS_Student(COCIS_Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)
   
         
class SCIT_Student(COCIS_Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)
             

class CS_Student(SCIT_Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)
    def print_statement(self,department=None):
        super().print_statement(department = "Computer Science")    

class SE_Student(SCIT_Student):
    def __init__(self, Reg_number, Student_number, Fullname):
        super().__init__(Reg_number, Student_number, Fullname)
    def print_statement(self,department=None):
        super().print_statement(department = "Networks")  

student1 = EDUC_Student("2020/U/172/EVE","2020172","Kaylwa John")
student1.print_statement()              

student2 = SE_Student("2020/u/18283/EVE","202018283","Lumu Musa")     
student2.print_statement() 

student3 = CS_Student("2020/U/1725","20201725","Adongo Diana")
student3.print_statement()           