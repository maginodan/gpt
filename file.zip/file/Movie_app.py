import datetime

# Movie object
def create_movie(title, director, writer, cast, genre, year, copies):
    movie = {
        "title": title,
        "director": director,
        "writer": writer,
        "cast": cast,
        "genre": genre,
        "year": year,
        "copies": copies,
        "rented_by": None
    }
    return movie

# Member object
def create_member(name, username, phone, dob, reg_date):
    member = {
        "name": name,
        "username": username,
        "phone": phone,
        "dob": dob,
        "reg_date": reg_date
    }
    return member

# MovieLibrary object
def create_movie_library():
    library = {
        "movies": [],
        "members": [],
        "money": 0
    }
    return library

# Add movie to library
def add_movie(library, movie):
    library["movies"].append(movie)

# Add member to library
def add_member(library, member):
    library["members"].append(member)
    library["money"] += 10000

# Search movie in library
def search_movie(library, attribute, value):
    for movie in library["movies"]:
        if attribute == "title" and movie["title"] == value:
            return movie, "title"
        elif attribute == "genre" and movie["genre"] == value:
            return movie, "genre"
        elif attribute == "writer" and movie["writer"] == value:
            return movie, "writer"
        elif attribute == "director" and movie["director"] == value:
            return movie, "director"
        elif attribute == "cast" and value in movie["cast"]:
            return movie, "cast"
    return None, None


# Rent movie
def rent_movie(library, member, movie):
    if member["username"] not in [m["rented_by"] for m in library["movies"]]:
        if movie["rented_by"] is None:
            if movie["copies"] > 0:
                if member["reg_date"] + datetime.timedelta(days=365) > datetime.datetime.now():
                    if movie["genre"] not in ["rated", "horror", "violent"]:
                        movie["rented_by"] = member["username"]
                        movie["copies"] -= 1
                        return True
                    elif member["dob"].year + 18 <= datetime.datetime.now().year:
                        movie["rented_by"] = member["username"]
                        movie["copies"] -= 1
                        return True
                    else:
                        print("Member must be 18 or older to rent this movie!")
                else:
                    print("Member's subscription has expired!")
            else:
                print("No copies available for this movie!")
        else:
            print("Movie already rented!")
    else:
        print("Member has reached the maximum number of rentals (3)!")
    return False

# Renew membership
def renew_membership(library, member):
    member["reg_date"] = datetime.datetime.now()
    library["money"] += 1000

# Number of copies available for movie
def num_copies_available(library, movie):
    return movie["copies"]

# Check availability of movie
def is_movie_available(library, movie):
    return movie["copies"] > 0

# Who has rented movie
def who_has_rented_movie(library, movie):
    return movie["rented_by"]

# Display menu and get choice
def display_menu_get_choice():
    print("1. Add movie")
    print("2. Add member")
    print("3. Search movie")
    print("4. Rent movie")
    print("5. Renew membership")
    print("6. Number of copies available")
    print("7. Check availability")
    print("8. Who has rented movie")
    print("9. Exit")
    choice = int(input("Enter choice: "))
    return choice

# Main function
def main():
    # Create movie library
    library = create_movie_library()

    while True:
        # Display menu and get choice
        choice = display_menu_get_choice()

        # Add movie
        if choice == 1:
            title = input("Enter title: ")
            director = input("Enter director: ")
            writer = input("Enter writer: ")
            cast = input("Enter cast (separated by commas): ").split(",")
            genre = input("Enter genre: ")
            year = int(input("Enter year: "))
            copies = int(input("Enter number of copies: "))
            movie = create_movie(title, director, writer, cast, genre, year, copies)
            add_movie(library, movie)

        # Add member
        elif choice == 2:
            name = input("Enter name (first middle last): ").split(" ")
            username = input("Enter username: ")
            phone = input("Enter phone number: ")
            dob = datetime.datetime.strptime(input("Enter date of birth (YYYY-MM-DD): "), "%Y-%m-%d")
            reg_date = datetime.datetime.now()
            member = create_member(name, username, phone, dob, reg_date)
            add_member(library, member)

        # Search movie
        elif choice == 3:
            attribute = input("Enter attribute to search by (title, genre, writer, director, cast): ")
            value = input("Enter value: ")
            movie, attr = search_movie(library, attribute, value)
            if movie is not None:
                print(f"Title: {movie['title']}")
                print(f"{attr}: {value}")
            else:
                print("Movie not found!")

        # Rent movie
        elif choice == 4:
            username = input("Enter member username: ")
            title = input("Enter movie title: ")
            member = None
            movie = None
            for m in library["members"]:
                if m["username"] == username:
                    member = m
                    break
            if member is not None:
                for m in library["movies"]:
                    if m["title"] == title:
                        movie = m
                        break
                if movie is not None:
                    if rent_movie(library, member, movie):
                        print("Movie rented successfully!")
                    else:
                        print("Movie could not be rented!")
                else:
                    print("Movie not found!")
            else:
                print("Member not found!")

        # Renew membership
        elif choice == 5:
            username = input("Enter member username: ")
            member = None
            for m in library["members"]:
                if m["username"] == username:
                    member = m
                    break
            if member is not None:
                renew_membership(library, member)
                print("Membership renewed successfully!")
            else:
                print("Member not found!")

        # Number of copies available
        elif choice == 6:
            title = input("Enter movie title: ")
            movie = None
            for m in library["movies"]:
                if m["title"] == title:
                    movie = m
                    break
            if movie is not None:
                print(f"Number of copies available for '{title}': {num_copies_available(library, movie)}")
            else:
                print("Movie not found!")

        # Check availability
        elif choice == 7:
            title = input("Enter movie title: ")
            movie = None
            for m in library["movies"]:
                if m["title"] == title:
                    movie = m
                    break
            if movie is not None:
                if is_movie_available(library, movie):
                    print(f"'{title}' is available!")
                else:
                    print(f"'{title}' is not available!")
            else:
                print("Movie not found!")

        # Who has rented movie
        elif choice == 8:
            title = input("Enter movie title: ")
            movie = None
            for m in library["movies"]:
                if m["title"] == title:
                    movie = m
                    break
            if movie is not None:
                rented_by = who_has_rented_movie(library, movie)
                if rented_by is None:
                    print("Movie has not been rented!")
                else:
                    print(f"'{title}' rented by {rented_by}")
            else:
                print("Movie not found!")

        # Exit
        elif choice == 9:
            break

# Run program
main()



