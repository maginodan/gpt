import pickle


class Book:
    def __init__(self, ISBN, author, year, title, serial_number, number_of_copies):
        self.ISBN = ISBN
        self.author = author
        self.year = year
        self.title = title
        self.serial_number = serial_number
        self.number_of_copies = number_of_copies
        self.available_copies = number_of_copies

    def borrow(self):
        if self.available_copies > 0:
            self.available_copies -= 1
            return True
        return False

    def return_book(self):
        if self.available_copies < self.number_of_copies:
            self.available_copies += 1
            return True
        return False


class Student:
    def __init__(self, student_number, name, date_of_birth, course, registration_number):
        self.student_number = student_number
        self.name = name
        self.date_of_birth = date_of_birth
        self.course = course
        self.registration_number = registration_number
        self.borrowed_books = []

    def borrow_book(self, book):
        if len(self.borrowed_books) < 3 and book.borrow():
            self.borrowed_books.append(book)
            return True
        return False

    def return_book(self, book):
        if book in self.borrowed_books:
            self.borrowed_books.remove(book)
            book.return_book()
            return True
        return False


def save_state(book_list, student_list, filename="library_state.pkl"):
    with open(filename, "wb") as f:
        pickle.dump([book_list, student_list], f)


def load_state(filename="library_state.pkl"):
    try:
        with open(filename, "rb") as f:
            return pickle.load(f)
    except FileNotFoundError:
        return [], []


def add_student(student_list):
    student_number = input("Enter student number: ")
    name = input("Enter name: ")
    date_of_birth = input("Enter date of birth (YYYY-MM-DD): ")
    course = input("Enter course: ")
    registration_number = input("Enter registration number: ")

    new_student = Student(student_number, name, date_of_birth, course, registration_number)
    student_list.append(new_student)
    print("Student added successfully!")


def add_book(book_list):
    ISBN = input("Enter ISBN: ")
    author = input("Enter author: ")
    year = input("Enter year: ")
    title = input("Enter title: ")
    serial_number = input("Enter serial number: ")
    number_of_copies = int(input("Enter number of copies: "))

    new_book = Book(ISBN, author, year, title, serial_number, number_of_copies)
    book_list.append(new_book)
    print("Book added successfully!")


def rent_book(student_list, book_list):
    student_number = input("Enter student number: ")
    ISBN = input("Enter ISBN: ")
    serial_number = input("Enter serial number: ")

    student = next((s for s in student_list if s.student_number == student_number), None)
    if not student:
        print("Student not found!")
        return

    book = next((b for b in book_list if b.ISBN == ISBN and b.serial_number == serial_number), None)
    if not book:
        print("Book not found!")
        return

    if student.borrow_book(book):
        print(f"Book '{book.title}' rented successfully!")
    else:
        print("Could not rent the book (either no copies available or limit reached).")


def return_book(student_list):
    student_number = input("Enter student number: ")
    student = next((s for s in student_list if s.student_number == student_number), None)
    if not student:
        print("Student not found!")
        return

    print("Borrowed books:")
    for index, book in enumerate(student.borrowed_books):
        print(f"{index + 1}. {book.title} (ISBN: {book.ISBN})")

    choice = int(input("Enter the number of the book to return: ")) - 1
    if 0 <= choice < len(student.borrowed_books):
        book = student.borrowed_books[choice]
        if student.return_book(book):
            print(f"Book '{book.title}' returned successfully!")
        else:
            print("Failed to return the book.")
    else:
        print("Invalid choice!")


def main():
    book_list, student_list = load_state()

    while True:
        print("\nLibrary Management System")
        print("1. Add student")
        print("2. Add book")
        print("3. Rent book")
        print("4. Return book")
        print("5. Quit")
        choice = input("Enter your choice: ")

        if choice == "1":
            add_student(student_list)
        elif choice == "2":
            add_book(book_list)
        elif choice == "3":
            rent_book(student_list, book_list)
        elif choice == "4":
            return_book(student_list)
        elif choice == "5":
            save_state(book_list, student_list)
            print("Application state saved. Goodbye!")
            break
        else:
            print("Invalid choice! Try again.")


if __name__ == "__main__":
    main()
