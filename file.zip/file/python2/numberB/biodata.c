#include <stdio.h>

// Structure to represent student bio-data
struct Student {
    char registrationNumber[50];
    char firstName[50];
    char lastName[50];
    int age;
};

// Function to capture and register student bio-data
void registerStudent(struct Student *student) {
    printf("Enter Registration Number: ");
    scanf("%s", student->registrationNumber);

    printf("Enter First Name: ");
    scanf("%s", student->firstName);

    printf("Enter Last Name: ");
    scanf("%s", student->lastName);

    printf("Enter Age: ");
    scanf("%d", &student->age);
}

// Function to print student bio-data
void printStudent(struct Student student) {
    printf("\nRegistration Number: %s\n", student.registrationNumber);
    printf("Name: %s %s\n", student.firstName, student.lastName);
    printf("Age: %d\n", student.age);
}

int main() {
    FILE *file;
    struct Student student;
    int continueFlag = 1;

    // Open a file for writing
    file = fopen("student_information.txt", "w");

    if (file == NULL) {
        printf("Error opening file.\n");
        return 1;
    }

    // Loop to register students until the user chooses to stop
    while (continueFlag == 1) {
        // Capture and register student bio-data
        registerStudent(&student);

        // Print student bio-data to the screen
        printStudent(student);

        // Write student bio-data to the file
        fprintf(file, "Registration Number: %s\n", student.registrationNumber);
        fprintf(file, "Name: %s %s\n", student.firstName, student.lastName);
        fprintf(file, "Age: %d\n", student.age);
        fprintf(file, "------------------------\n");

        // Ask the user if they want to continue
        printf("\nEnter 1 to continue, or any other integer to stop: ");
        scanf("%d", &continueFlag);
    }

    // Close the file
    fclose(file);

    printf("\nStudent data written to 'student_information.txt' successfully.\n");

    return 0;
}

