class MathOperations:
    @staticmethod
    def add(a, b):
        return a + b

    @staticmethod
    def subtract(a, b):
        return a - b

    @staticmethod
    def multiply(a, b):
        return a * b

    @staticmethod
    def divide(a, b):
        if b == 0:
            return "Cannot divide by zero"
        return a / b

class GPA_Calculator:
    @staticmethod
    def calculate_c(subjects):
        total_credit_points = 0
        total_credits = 0

        for credit, grade in subjects:
            credit_points = MathOperations.multiply(credit, grade)
            total_credit_points = MathOperations.add(total_credit_points, credit_points)
            total_credits = MathOperations.add(total_credits, credit)

        g = MathOperations.divide(total_credit_points, total_credits)
        return g

subjects_data = [
    (4, 3.5),
    (3, 4.0),
    (3, 3.0),
    (4, 4.0),
]

G1 = GPA_Calculator.calculate_c(subjects_data)

file_name = 'output3.txt'
with open(file_name, 'w') as file:
    file.write(f"Calculated : {G1:.2f}")

print(f"written to {file_name} successfully.")
