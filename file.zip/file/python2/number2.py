def calculate_c(subjects):
    total_credit_points = 0
    total_credits = 0

    for credit, grade in subjects:
        credit_points = credit * grade
        total_credit_points += credit_points
        total_credits += credit

    g = total_credit_points / total_credits
    return g

def read_data_from_file(file_name):
    subjects_data = []
    with open(file_name, 'r') as file:
        for line in file:
            credit, grade = map(float, line.strip().split())
            subjects_data.append((credit, grade))
    return subjects_data

 # put your file name
file_name = 'inputdata.txt' 
subjects_data = read_data_from_file(file_name)
G1 = calculate_c(subjects_data)

output_file_name = 'output2.txt'
with open(output_file_name, 'w') as file:
    file.write(f"Calculated : {G1:.2f}")

print(f"written to {output_file_name} successfully.")
