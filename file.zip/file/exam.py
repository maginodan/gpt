class Student:
    total_students = 0
    id_counter = 0

    def __init__(self, registration_number, student_number, full_name):
        self.id_number = str(Student.id_counter).zfill(4)
        self.registration_number = registration_number
        self.student_number = student_number
        self.full_name = full_name
        Student.total_students += 1
        Student.id_counter += 1

    def print_statement(self, college=None, department=None):
        print(f"Name: {self.full_name}")
        print(f"University: Makerere")
        print(f"College: {college}")
        print(f"Reg No: {self.registration_number}")
        print(f"Student Number: {self.student_number}")
        if department:
            print(f"Department: {department}")
        print(f"ID No: {self.id_number}")
        print(f"Total Students: {self.total_students}\n")

    
    #The method below will be called incase of editing the registration number
    def edit_registration_number(self):
        new_reg_num = input("Enter your new registration number: ")
        self.registration_number = new_reg_num


class CEDAT_Student(Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)
    
    def print_statement(self):
        super().print_statement(college="CEDAT")

class CoCIS_Student(Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)
    
    def print_statement(self, department=None):
        super().print_statement(college="CoCIS", department=department)

class EDUC_Student(Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)
    
    def print_statement(self):
        super().print_statement(college="Education")

class EASLIS_Student(CoCIS_Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)

class SCIT_Student(CoCIS_Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)

class CS_Student(CoCIS_Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)
    
    def print_statement(self):
        super().print_statement(department="Computer Science")

class SE_Student(CoCIS_Student):
    def __init__(self, registration_number, student_number, full_name):
        super().__init__(registration_number, student_number, full_name)
    
    def print_statement(self):
        super().print_statement(department="Networks")

student1 = EDUC_Student("2020/U/172", "2020172", "Kayiwa John")
student1.print_statement()

student2 = SE_Student("2020/U/18283/EVE", "202018283", "Lumu Musa")
student2.print_statement()

student3 = CS_Student("2020/U/1725", "20201725", "Adongo Diana")
student3.print_statement()
