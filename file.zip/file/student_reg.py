import json
import os

# Student Information (Edit the following lines)
STUDENT_NAME = "my_name"
STUDENT_NUMBER = "my_std_no"
REGISTRATION_NUMBER = "my_reg_no"

class Student:
    def __init__(self, admin_no, name):
        """Initialize a student with admin number and name."""
        self.admin_no = admin_no
        self.name = name
        self.marks = {"Maths": None, "Science": None, "English": None, "SST": None}

    def set_marks(self, subject, marks):
        """Set marks for a specific subject."""
        if subject in self.marks:
            self.marks[subject] = marks
        else:
            print("Invalid subject!")

    def get_marks(self, subject):
        """Get student's mark for a specific subject."""
        return self.marks[subject]

    def edit_marks(self, subject, new_marks):
        """Edit marks for a specific subject."""
        if subject in self.marks:
            self.marks[subject] = new_marks
        else:
            print("Subject not found")

    def to_dict(self):
        """Convert Student object to dictionary for JSON serialization."""
        return {
            "admin_no": self.admin_no,
            "name": self.name,
            "marks": self.marks
        }

    @classmethod
    def from_dict(cls, data):
        """Create a Student object from a dictionary."""
        student = cls(data['admin_no'], data['name'])
        student.marks = data['marks']
        return student

class Gradebook:
    def __init__(self, filename='gradebook.json'):
        """Initialize an empty gradebook and load existing data."""
        self.students = {}
        self.filename = filename
        self.load_gradebook()

    def add_student(self, student):
        """Add a student to the gradebook."""
        if student.admin_no in self.students:
            print("Student already exists!")
            return False
        self.students[student.admin_no] = student
        self.save_gradebook()  # Save after adding a student
        print(f"Student {student.name} added successfully!")
        return True

    def get_student(self, admin_no):
        """Retrieve a student by admin number."""
        return self.students.get(admin_no, None)

    def delete_student(self, admin_no):
        """Delete a student from the gradebook using their admin number."""
        if admin_no in self.students:
            del self.students[admin_no]
            self.save_gradebook()  # Save after deleting a student
            print("Student deleted successfully!")
            return True
        else:
            print("Student not found!")
            return False

    def view_statistics(self):
        """Display statistics about the grades."""
        stats = {subject: {"Average": 0, "Total Students": 0} for subject in ["Maths", "Science", "English", "SST"]}
        for student in self.students.values():
            for subject, marks in student.marks.items():
                if marks is not None:
                    stats[subject]["Average"] += marks
                    stats[subject]["Total Students"] += 1

        for subject in stats:
            total_students = stats[subject]["Total Students"]
            if total_students > 0:
                stats[subject]["Average"] = stats[subject]["Average"] / total_students
        print(stats)

    def save_gradebook(self):
        """Save the gradebook to a JSON file."""
        with open(self.filename, 'w') as f:
            json.dump({admin_no: student.to_dict() for admin_no, student in self.students.items()}, f)

    def load_gradebook(self):
        """Load the gradebook from a JSON file."""
        if os.path.exists(self.filename):
            with open(self.filename, 'r') as f:
                data = json.load(f)
                for student_data in data.values():
                    student = Student.from_dict(student_data)
                    self.students[student.admin_no] = student

def print_menu():
    print("--------------------Menu--------------------")
    print("1 - Add student with marks")
    print("2 - Delete student by admin number")
    print("3 - View statistics about the grades")
    print("4 - View student grades")
    print("5 - Edit student grades")
    print("6 - Print Gradebook")
    print("q - Quit system\n")

def main():
    """Main function to run the gradebook application."""
    gradebook = Gradebook()
    while True:
        print_menu()
        choice = input("Select an option: ").strip().lower()

        if choice == '1':
            admin_no = input("Enter admin number: ").strip()
            name = input("Enter student name: ").strip()
            student = Student(admin_no, name)
            for subject in student.marks.keys():
                marks = input(f"Enter marks for {subject} (leave blank for None): ").strip()
                student.set_marks(subject, int(marks) if marks.isdigit() else None)
            gradebook.add_student(student)

        elif choice == '2':
            admin_no = input("Enter admin number to delete: ").strip()
            gradebook.delete_student(admin_no)

        elif choice == '3':
            gradebook.view_statistics()

        elif choice == '4':
            admin_no = input("Enter admin number to view grades: ").strip()
            student = gradebook.get_student(admin_no)
            if student:
                print(student.marks)
            else:
                print("Student not found!")

        elif choice == '5':
            admin_no = input("Enter admin number: ").strip()
            student = gradebook.get_student(admin_no)
            if student:
                subject = input("Enter subject to edit marks: ").strip()
                if subject in student.marks:
                    marks = input(f"Enter new marks for {subject}: ").strip()
                    student.edit_marks(subject, int(marks))
                    gradebook.save_gradebook()
                else:
                    print("Invalid subject!")
            else:
                print("Student not found!")

        elif choice == '6':
            print("Gradebook:")
            for admin_no, student in gradebook.students.items():
                print(f"{admin_no}: {student.name} - {student.marks}")

        elif choice == 'q':
            print("Exiting the system. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
