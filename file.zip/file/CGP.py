# MAGINO DANIEL / 2200721768 / 22/U/21768/PS

# define a function for converting marks to grades 
def convert_marks_to_grade(marks):
    if 90 <= marks <= 100:
        return 'A', 5
    elif 80 <= marks < 90:
        return 'B', 4
    elif 70 <= marks < 80:
        return 'C', 3
    elif 60 <= marks < 70:
        return 'D', 2
    elif 50 <= marks < 60:
        return 'E', 1
    else:
        return 'F', 0

def calculate_cgpa(marks, credit_units):
    grade_points = []
    
    # This a loop to convert marks to grade points
    for i in range(len(marks)):
        grade, grade_point = convert_marks_to_grade(marks[i])
        grade_points.append(grade_point)
        print(f"Course {i+1}: Mark = {marks[i]}, Grade = {grade}, Grade Point = {grade_point}, Credit Unit = {credit_units[i]}")

    # clculation of cgpa
    weighted_sum = sum(grade_point * credit_unit for grade_point, credit_unit in zip(grade_points, credit_units))
    
    total_credit_units = sum(credit_units)
    
    cgpa = weighted_sum / total_credit_units
    
    return cgpa


# define the basic calculator function
def basic_calculator(num1, num2):
    print(f"Addition: {num1 + num2}")
    print(f"Subtraction: {num1 - num2}")
    print(f"Multiplication: {num1 * num2}")
    if num2 != 0:
        print(f"Division: {num1 / num2:.2f}")
    else:
        print("Division: Can't divide by zero")

# Main Program
name = input("Enter your name: ")
student_number = input("Enter your student number: ")

# CGPA Calculation
marks = []
credit_units = []

for i in range(4):
    mark = int(input(f"Enter the mark for the course {i+1}: "))
    credit_unit = int(input(f"Enter the credit unit for the course {i+1}: "))
    marks.append(mark)
    credit_units.append(credit_unit)

cgpa = calculate_cgpa(marks, credit_units)
print(f"Your CGPA Result is: {cgpa:.2f}")

# Basic Calculator
num1 = int(student_number[-2])
num2 = int(student_number[-1])

print("Your Calculator results:")
basic_calculator(num1, num2)
