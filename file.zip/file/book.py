import pickle
import sys

# Classes
class Book:
    def __init__(self, ISBN, author, year, title, serial_number, number_of_copies):
        self.ISBN = ISBN
        self.author = author
        self.year = year
        self.title = title
        self.serial_number = serial_number
        self.number_of_copies = number_of_copies
        self.available_copies = number_of_copies

    def borrow(self):
        if self.available_copies > 0:
            self.available_copies -= 1
            return True
        return False

    def return_book(self):
        self.available_copies += 1


class Student:
    def __init__(self, student_number, name, date_of_birth, course, registration_number):
        self.student_number = student_number
        self.name = name
        self.date_of_birth = date_of_birth
        self.course = course
        self.registration_number = registration_number
        self.borrowed_books = []

    def borrow_book(self, book):
        if len(self.borrowed_books) < 3:
            self.borrowed_books.append(book)
            return True
        return False

    def return_book(self, book):
        self.borrowed_books.remove(book)


# Functions
def add_student(student_list):
    student_number = input("Enter student number: ")
    name = input("Enter name: ")
    date_of_birth = input("Enter date of birth (YYYY-MM-DD): ")
    course = input("Enter course: ")
    registration_number = input("Enter registration number: ")

    new_student = Student(student_number, name, date_of_birth, course, registration_number)
    student_list.append(new_student)
    print("Student added successfully!")


def add_book(book_list):
    ISBN = input("Enter ISBN: ")
    author = input("Enter author: ")
    year = input("Enter year: ")
    title = input("Enter title: ")
    serial_number = input("Enter serial number: ")
    number_of_copies = int(input("Enter number of copies: "))

    new_book = Book(ISBN, author, year, title, serial_number, number_of_copies)
    book_list.append(new_book)
    print("Book added successfully!")


def rent_book(student_list, book_list):
    student_number = input("Enter student number: ")
    ISBN = input("Enter ISBN: ")
    serial_number = input("Enter serial number: ")

    student = next((s for s in student_list if s.student_number == student_number), None)
    book = next((b for b in book_list if b.ISBN == ISBN and b.serial_number == serial_number), None)

    if not student or not book:
        print("Student or book not found!")
        return

    if book.borrow() and student.borrow_book(book):
        print(f"Book '{book.title}' rented to {student.name}.")
    elif not book.available_copies:
        print("No available copies of the book.")
    else:
        print(f"{student.name} already has 3 books borrowed.")


def get_students_with_book(student_list, ISBN, serial_number):
    students = [
        student.name
        for student in student_list
        for book in student.borrowed_books
        if book.ISBN == ISBN and book.serial_number == serial_number
    ]

    if students:
        print("Students possessing the book:")
        for student in students:
            print(student)
    else:
        print("No students possess this book.")


def get_student_details(student_list, student_number):
    student = next((s for s in student_list if s.student_number == student_number), None)
    if student:
        print(f"Name: {student.name}")
        print(f"Date of Birth: {student.date_of_birth}")
        print(f"Course: {student.course}")
        print(f"Registration Number: {student.registration_number}")
        print("Borrowed Books:", [book.title for book in student.borrowed_books])
    else:
        print("Student not found!")


def get_book_details(book_list, ISBN):
    book = next((b for b in book_list if b.ISBN == ISBN), None)
    if book:
        print(f"Title: {book.title}")
        print(f"Author: {book.author}")
        print(f"Year: {book.year}")
        print(f"Serial Number: {book.serial_number}")
        print(f"Number of Copies: {book.number_of_copies}")
        print(f"Available Copies: {book.available_copies}")
    else:
        print("Book not found!")


def save_state(student_list, book_list, filename="bookbank_state.pkl"):
    with open(filename, 'wb') as f:
        pickle.dump([student_list, book_list], f)


def load_state(filename="bookbank_state.pkl"):
    try:
        with open(filename, 'rb') as f:
            return pickle.load(f)
    except FileNotFoundError:
        return [], []


def quit_app(student_list, book_list):
    save_state(student_list, book_list)
    print("State saved. Application closed.")
    sys.exit()


# Main Application
def main():
    student_list, book_list = load_state()

    while True:
        print("\nMain Menu:")
        print("1. Add Student")
        print("2. Add Book")
        print("3. Rent Book")
        print("4. Get Student Details")
        print("5. Get Book Details")
        print("6. Quit")

        choice = input("Enter your choice: ")

        if choice == "1":
            add_student(student_list)
        elif choice == "2":
            add_book(book_list)
        elif choice == "3":
            rent_book(student_list, book_list)
        elif choice == "4":
            student_number = input("Enter student number: ")
            get_student_details(student_list, student_number)
        elif choice == "5":
            ISBN = input("Enter ISBN: ")
            get_book_details(book_list, ISBN)
        elif choice == "6":
            quit_app(student_list, book_list)
        else:
            print("Invalid choice! Try again.")


if __name__ == "__main__":
    main()
