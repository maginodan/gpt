import json
import os

class Account:
    def __init__(self, account_number, name, balance=0):
        """Initialize a bank account with account number, name, and balance."""
        self.account_number = account_number
        self.name = name
        self.balance = balance

    def deposit(self, amount):
        """Deposit money into the account."""
        if amount > 0:
            self.balance += amount
        else:
            print("Invalid amount. Please enter a positive value.")

    def withdraw(self, amount):
        """Withdraw money from the account."""
        if 0 < amount <= self.balance:
            self.balance -= amount
        else:
            print("Invalid amount or insufficient balance.")

    def edit_account(self, new_name):
        """Edit account holder's name."""
        self.name = new_name

    def to_dict(self):
        """Convert Account object to dictionary for JSON serialization."""
        return {
            "account_number": self.account_number,
            "name": self.name,
            "balance": self.balance
        }

    @classmethod
    def from_dict(cls, data):
        """Create an Account object from a dictionary."""
        return cls(data['account_number'], data['name'], data['balance'])

class Bank:
    def __init__(self, filename='bank_data.json'):
        """Initialize the bank system and load existing accounts."""
        self.accounts = {}
        self.filename = filename
        self.load_data()

    def register_account(self, account):
        """Register a new account."""
        if account.account_number in self.accounts:
            print("Account already exists.")
        else:
            self.accounts[account.account_number] = account
            self.save_data()
            print("Account successfully registered!")

    def get_account(self, account_number):
        """Retrieve an account by its account number."""
        return self.accounts.get(account_number, None)

    def delete_account(self, account_number):
        """Delete an account by its account number."""
        if account_number in self.accounts:
            del self.accounts[account_number]
            self.save_data()
            print("Account deleted successfully.")
        else:
            print("Account not found.")

    def view_statistics(self):
        """View statistics about the accounts."""
        total_accounts = len(self.accounts)
        total_balance = sum(account.balance for account in self.accounts.values())
        average_balance = total_balance / total_accounts if total_accounts > 0 else 0
        max_balance = max((account.balance for account in self.accounts.values()), default=0)
        min_balance = min((account.balance for account in self.accounts.values()), default=0)

        return {
            "total_accounts": total_accounts,
            "total_balance": total_balance,
            "average_balance": average_balance,
            "max_balance": max_balance,
            "min_balance": min_balance
        }

    def save_data(self):
        """Save account data to a JSON file."""
        with open(self.filename, 'w') as f:
            json.dump({acc_num: acc.to_dict() for acc_num, acc in self.accounts.items()}, f)

    def load_data(self):
        """Load account data from a JSON file."""
        if os.path.exists(self.filename):
            with open(self.filename, 'r') as f:
                data = json.load(f)
                for account_data in data.values():
                    account = Account.from_dict(account_data)
                    self.accounts[account.account_number] = account

def print_menu():
    print("\n----------- Menu -----------")
    print("1 - Register Account")
    print("2 - View Account Balance")
    print("3 - Deposit Money")
    print("4 - Withdraw Money")
    print("5 - Edit Account Details")
    print("6 - View Statistics")
    print("7 - Delete Account")
    print("q - Quit System")

def main():
    """Main function to run the bank management system."""
    bank = Bank()

    while True:
        print_menu()
        choice = input("Select an option: ").strip().lower()

        if choice == '1':
            account_number = input("Enter account number: ").strip()
            name = input("Enter account holder's name: ").strip()
            initial_balance = float(input("Enter initial balance: ").strip())
            account = Account(account_number, name, initial_balance)
            bank.register_account(account)

        elif choice == '2':
            account_number = input("Enter account number: ").strip()
            account = bank.get_account(account_number)
            if account:
                print(f"Account Balance: {account.balance}")
            else:
                print("Account not found.")

        elif choice == '3':
            account_number = input("Enter account number: ").strip()
            account = bank.get_account(account_number)
            if account:
                amount = float(input("Enter amount to deposit: ").strip())
                account.deposit(amount)
                bank.save_data()
                print("Deposit successful!")
            else:
                print("Account not found.")

        elif choice == '4':
            account_number = input("Enter account number: ").strip()
            account = bank.get_account(account_number)
            if account:
                amount = float(input("Enter amount to withdraw: ").strip())
                account.withdraw(amount)
                bank.save_data()
                print("Withdrawal successful!")
            else:
                print("Account not found.")

        elif choice == '5':
            account_number = input("Enter account number: ").strip()
            account = bank.get_account(account_number)
            if account:
                new_name = input("Enter new name for account holder: ").strip()
                account.edit_account(new_name)
                bank.save_data()
                print("Account details updated!")
            else:
                print("Account not found.")

        elif choice == '6':
            stats = bank.view_statistics()
            print("Bank Statistics:")
            for key, value in stats.items():
                print(f"{key.capitalize()}: {value}")

        elif choice == '7':
            account_number = input("Enter account number: ").strip()
            bank.delete_account(account_number)

        elif choice == 'q':
            print("Exiting the system. Goodbye!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
