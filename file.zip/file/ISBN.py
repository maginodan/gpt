class Book:
  total_copies=0
  def __init__(self,serial_num,ISBN):
      self.serial_num=serial_num
      self.ISBN=ISBN
      Book.total_copies+=1

  def details(self):
    print('----------')
    print('ISBN:',self.ISBN)
    print('Serial number:', self.serial_num)
    print('num copies:',self.total_copies)

bk1=Book('001','566')
bk1.details()
bk2=Book('002','566')
bk1.details()
bk2.details()
bk1.serial_num='003'
bk1.ISBN='58'
bk1.total_copies+=1
print('------After Change------')
bk1.details()
bk2.details()