from docx import Document
import os

# Constants
RESULTS_FILE = 'output_results.docx'
STUDENT_NUMBERS = [216022204, 216002204, 216007570, 216002774]
COURSE_UNITS = [
    {"Code": "CSK 1101", "Course Name": "Communication Skills", "LH": 45, "PH": 30, "CH": 60, "CU": 4, "Remark": "Old"},
    {"Code": "CSC 1102", "Course Name": "Structured & Object-Oriented Pro", "LH": 30, "PH": 60, "CH": 60, "CU": 4, "Remark": "New"},
    {"Code": "CSC 1101", "Course Name": "Computer Architecture & Organisation", "LH": 30, "PH": 60, "CH": 60, "CU": 4, "Remark": "Modified"},
    {"Code": "CSC 1105", "Course Name": "Mathematics for Computer Science", "LH": 30, "PH": 60, "CH": 60, "CU": 4, "Remark": "New"}
]

# Function to calculate CGPA
def calculate_cgpa(marks, grades, credit_units):
    total_gp_cu = sum([marks_to_gp(mark) * cu for mark, cu in zip(marks, credit_units)])
    total_cu = sum(credit_units)
    return total_gp_cu / total_cu

# Function to convert marks to GP using the given tables
def marks_to_gp(marks):
    if marks is None:
        return 0.0  # Handle the case where marks are None (or any other invalid value)

    if 90 <= marks <= 100:
        return 5.0  # 90 to 100 is grade A+ and GP 5.0

    elif 80 <= marks <= 89:
        return 5.0  # 80 to 89 is grade A and GP 5.0

    elif 75 <= marks <= 79:
        return 4.5  # 75 to 79 is grade B+ and GP 4.5

    elif 70 <= marks <= 74:
        return 4.0  # 70 to 74 is grade B and GP 4.0

    elif 65 <= marks <= 69:
        return 3.5  # 65 to 69 is grade C+ and GP 3.5

    elif 60 <= marks <= 64:
        return 3.0  # 60 to 64 is grade C and GP 3.0

    elif 55 <= marks <= 59:
        return 2.5  # 55 to 59 is grade D+ and GP 2.5

    elif 50 <= marks <= 54:
        return 2.0  # 50 to 54 is grade D and GP 2.0

    elif 45 <= marks <= 49:
        return 1.5  # 45 to 49 is grade E and GP 1.5

    elif 40 <= marks <= 44:
        return 1.0  # 40 to 44 is grade E- and GP 1.0

    else:
        return 0.0  # Below 40 is grade F and GP 0.0

# Function for basic calculator
def basic_calculator(student_numbers):
    student_sum = sum(student_numbers)
    extracted_values = [int(val) for val in str(student_sum)[1:-1]]  # Remove the '8' from the left
    # Perform operations based on the extracted values
    result = extracted_values[0] * 1 + extracted_values[1] * 2 + extracted_values[2] * 3 + extracted_values[3] * 4
    return result

def write(doc : Document, doc_name : str):
    doc.save(doc_name)

# Function to create Word document and write results
def write_to_word(results_a, results_b):
    document = Document()
    if os.path.exists(RESULTS_FILE):
        document = Document(RESULTS_FILE)

    document.add_heading('Results from CGPA Calculator and Basic Calculator', level=1)

    document.add_heading('Results from CGPA Calculator', level=2)
    document.add_paragraph(results_a)

    document.add_heading('Results from Basic Calculator', level=2)
    document.add_paragraph(results_b)

    try:
        # document.save(RESULTS_FILE)
        write(document, RESULTS_FILE)
        print(f"Results saved to {RESULTS_FILE}")
    except PermissionError as e:
        print(f"Error: {e}")
        print("Make sure the file is closed incase you want to update anything!!!.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        if not document.part.package:
            document.part.package.close()

# Example usage of CGPA calculator
marks = [85, 78, 92, 40]
grades = ['A', 'B+', 'A+', 'F']
credit_units = [4, 4, 4, 4]
cgpa_result = calculate_cgpa(marks, grades, credit_units)

# Example usage of basic calculator
calculator_result = basic_calculator(STUDENT_NUMBERS)

# Save results to Word document
write_to_word(f'CGPA Result: {cgpa_result}', f'Basic Calculator Result: {calculator_result}')