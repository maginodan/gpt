movies={'little women':[1899, ['Cadet','Ventil','Tyson Blanka','romance']],
        'after':[1989, ['Tilly','Von','Jordan Vutition','action']],
        'second act':[2002,['Phantom','Barley','Histon Val','romance']],
        'invisible':[2010,['Paul','Travis','Scott Adikins','horror']],
        'the choice':[2005,['Clement','Dezo','harry patron','thriller']],
        'the intern':[1995,['Pitbul','Klint','rebecca ferguson','drama']],
        'Bad Boys for life':[2010,['Nethervans','Cedric hants','Levis Travis','action']],
        'Avengers':[2019,['hulk','Johnsons','Cirus banks','action']]}

Rented=[]

genres={'thriller', 'drama', 'romance'}

member={1:[['Magino','Ken','Daniel'],['Kent'],[772842331],[28],[8],[1999]],
       2:[['John','Frank','Danielz'],['Danz'],[705829594],[17],[12],[1998]],
       3:[['Ojok','Alfred','Otim'],['Jerox'],[700556754],[5],[9],[1995]]}

menu=['Add New Movie', 'Rent out a Movie', 'Check movie availability', 'Add a genre','Get number of movies available',
'Get number of members available', 'Add a member','Discard a movie',
'Check Rented movie','Number of Genre available','Discard a member','Quit']

while True:
         print('== Welcome To Our Movie Application ==\n')
         print('pick an option to continue')
         i=0
         while i < len(menu):
             print('\t'+str(i)+'-'+menu[i])
             i+=1
         choice = input('Pick an operation to continue\n')
         try:
                choice = int(choice)
                if(choice>=len(menu)):
                            print("invalid selection")
                if choice == 11:
                    break
                if choice == 0:
                  
                  print("Enter movie details: \n")
                  movie_name=input("firstname: \n")
                  year=int(input("Year of release: \n"))
                  director=input("movie_director: \n")
                  writer=input("movie_writer: \n") 
                  cast=input("movie_cast: \n")
                  rating=input("movie_Rating/genre: \n")       
                  movies[movie_name]=[year,[director,writer,cast,rating]]
                  genres.add(rating)
                  print("Movie Added\n, Your new list of movies is: ",movies)


                if choice == 1:
                      movie_name = input("please enter the movie name\n")
                      Rented.append(movie_name)
                      movies.pop(movie_name)
                      print("Movie has been Rented\n, Your new list of movies is: ",movies)
                        
                if choice == 2:
                        movie_available = input("please enter the movie name\n")
                        if movie_available in movies:
                              print("...The movie is available...\n")
                        else:
                              print("Not available at the moment!!!\n")

                if choice == 3:
                      genre_name = input("please enter the genre name\n")
                      print("Your previous list of genre is: ", genres)
                      genres.add(genre_name)
                      print("Genre Added\n, Your new list of genre is: ",genres) 
                                

                if choice == 4:
                      print("number of movies\n, Your new list of movies is:\n",movies) 
                      print("The number of movies are: ",len(movies))     

                if choice == 5:
                      print("number of members\n, Your new list of members is:\n",member) 
                      print("members available are: ",len(member)) 

                if choice == 6: 
                    print("Please Check the number of members available first in option 5 in order to know which position/key to enter!!") 
                    customer=int(input("enter your position/key number:\n"))
                    first_name=input("firstname: \n")
                    middle_name=input("middle_name: \n")
                    last_name=input("last_name: \n")
                    User_name=input("username: \n")
                    phone=int(input("phone_number: \n"))
                    print("Please enter the date of birth beginning with day,month and year:\n")
                    Day=int(input("DAY: \n"))
                    Month=int(input("MONTH: \n"))
                    Year=int(input("YEAR: \n"))
                    member[customer]=[first_name,middle_name,last_name],[User_name],[phone],[Day],[Month],[Year]
                    
                    print("member Added\n, Your new list of members is: ",member)   
                      

                if choice == 7:
                  x=input("enter movie name to be discarded:\n")
                  del movies[x]
                  print("New Movie list is: \n",movies)
                  print("Movie deleted is: \n",x)

                        
                if choice == 8:
                  
                    if len(Rented)>0: 
      #when a user enters option 8 before renting it will display there are no movies rented.
                      print("List of rented movies:",Rented)  #This line will display the rented movies
                      
                    else:
                       print("!!!There are no Rented movies!!!")   

                if choice == 9:
                      print("number of genres\n, Your new list of genres is:\n",genres) 
                      print("The number of geners available: ",len(genres))      

                if choice == 10:
                  discard_member=int(input("enter the member's key/position:\n"))
                  del member[discard_member]
                  print("New list is: \n",member)
                  print("Member discarded is: \n",discard_member)        

         except Exception as e:
             print("Error occured:",e)
print("you choose to quit, bye")
exit(0)         
