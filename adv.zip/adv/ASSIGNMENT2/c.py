import matplotlib.pyplot as plt
from docx import Document
from docx.shared import Inches

# Base class representing a generic product
class Product:
    def __init__(self, name, price):
        self._name = name  # Encapsulation: Using underscore to indicate a private variable
        self._price = price

    def get_price(self):
        """Returns the base price of the product."""
        return self._price

    def __str__(self):
        return f"Product Name: {self._name}, Price: ${self._price:.2f}"

# Derived class inheriting from Product to apply discounts
class DiscountedProduct(Product):
    def __init__(self, name, price, discount_rate):
        super().__init__(name, price)  # Inheritance: Reusing the constructor of Product
        self._discount_rate = discount_rate

    def get_discounted_price(self):
        """Calculates and returns the price after applying the discount."""
        discounted_price = self._price * (1 - self._discount_rate / 100)
        return discounted_price

    def __str__(self):
        discounted_price = self.get_discounted_price()
        return f"{super().__str__()}, Discounted Price: ${discounted_price:.2f}"

# Using the classes to demonstrate functionality
# For demonstration, assume the last two digits of the student number are 68
student_num_last_two = 68

# Create a Product object
product = Product("Gadget", student_num_last_two * 10)  # Price set to 68 * 10 = $680

# Create a DiscountedProduct object with a 15% discount
discounted_product = DiscountedProduct("Gadget", student_num_last_two * 10, 15)

# Print product details
print(discounted_product)

# Visualization using Matplotlib
prices = [product.get_price(), discounted_product.get_discounted_price()]
labels = ['Original Price', 'Discounted Price']

# Plotting the prices and saving as an image
plt.figure(figsize=(8, 5))
plt.bar(labels, prices, color=['blue', 'green'])
plt.title('Price Comparison Before and After Discount')
plt.ylabel('Price in USD')
plt.savefig('price_comparison_plot.png')  # Save the plot as an image
plt.show()

# Create a Word document and write the output to it
doc = Document()
doc.add_heading('Product Price Details', level=1)
doc.add_paragraph(str(discounted_product))

# Add the plot image to the document
doc.add_picture('price_comparison_plot.png', width=Inches(5.5))

# Save the document
doc.save('product_price_details.docx')

print("Output written to 'product_price_details.docx'")
