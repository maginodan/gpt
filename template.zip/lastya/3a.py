class User:
    def __init__(self, username, role):
        """
        Initializes the user with a username and role.
        Role assignment is validated to ensure it adheres to defined roles.
        """
        self.username = username
        if role not in ['admin', 'user', 'viewer']:  # Restrict to predefined roles
            raise ValueError(f"Invalid role: {role}. Role must be 'admin', 'user', or 'viewer'.")
        self._role = role  # Encapsulation: make role a private attribute

    def can_access_sensitive_data(self):
        """
        Determines if the user can access sensitive data.
        Implements PoLP by ensuring only specific roles can access such data.
        """
        return self._role == 'admin'  # Only 'admin' role can access sensitive data

    def can_edit_data(self):
        """
        Determines if the user can edit data.
        Adds additional restrictions for other roles.
        """
        return self._role in ['admin', 'user']  # 'admin' and 'user' roles can edit data

    def __str__(self):
        return f"User(username='{self.username}', role='{self._role}')"

# Usage
try:
    user1 = User('Alice', 'admin')
    user2 = User('Bob', 'user')
    user3 = User('Charlie', 'viewer')  # Viewer role with restricted access

    print(f"{user1}: Can access sensitive data? {user1.can_access_sensitive_data()}")
    print(f"{user2}: Can access sensitive data? {user2.can_access_sensitive_data()}")
    print(f"{user3}: Can access sensitive data? {user3.can_access_sensitive_data()}")
    print(f"{user2}: Can edit data? {user2.can_edit_data()}")
    print(f"{user3}: Can edit data? {user3.can_edit_data()}")
except ValueError as e:
    print(e)
