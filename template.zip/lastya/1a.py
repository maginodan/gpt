from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.http import JsonResponse

@method_decorator(csrf_protect, name='dispatch')
class RegistrationView(View):
    def get(self, request):
        # Render registration form
        return render(request, 'registration_form.html')

    def post(self, request):
        # Process registration data
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if not username or not email or not password:
            return JsonResponse({'error': 'All fields are required.'}, status=400)

        try:
            # Save user to the database
            if User.objects.filter(username=username).exists():
                return JsonResponse({'error': 'Username already taken.'}, status=400)
            if User.objects.filter(email=email).exists():
                return JsonResponse({'error': 'Email already registered.'}, status=400)

            user = User.objects.create_user(username=username, email=email, password=password)
            user.full_clean()  # Validates fields
            user.save()
            return HttpResponse("Registration successful")
        except ValidationError as e:
            return JsonResponse({'error': str(e)}, status=400)
