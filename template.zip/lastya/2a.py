class SecureLoginSystem:
    def __init__(self, username, password):
        # Encapsulation: Using private attributes
        self._username = username
        self._password = password

    def _is_strong_password(self):
        """
        Private method to validate the password strength.
        Abstraction: Hides implementation details for password validation.
        """
        if len(self._password) < 8:
            return False
        if not any(char.isdigit() for char in self._password):
            return False
        if not any(char.isupper() for char in self._password):
            return False
        if not any(char.islower() for char in self._password):
            return False
        return True

    def validate_credentials(self):
        """
        Public method to validate user credentials.
        Combines username and password checks.
        """
        if not self._username or not self._password:
            print("Username or password cannot be empty.")
            return False

        if self._is_strong_password():
            return True
        else:
            print("Password must be at least 8 characters long, contain both uppercase and lowercase letters, and include at least one number.")
            return False

# Example usage
user = SecureLoginSystem("example_user", "Secure123")  # Strong password example
if user.validate_credentials():
    print("Login successful")
else:
    print("Invalid credentials")
